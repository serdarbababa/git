//
//  Net.h
//  neural
//
//  Created by ser on 1/27/14.
//  Copyright (c) 2014 ser. All rights reserved.
//

#ifndef __neural__Net__
#define __neural__Net__

#include <iostream>
#include <cassert>

#include "Neuron.h"
class Net
{
public:
    Net(const vector<unsigned> &topology);
    void feedForward(const vector<double> &inputVals);
    void backProp(const vector<double> &targetVals);
    void getResults(vector<double> &resultVals) const;
    double getRecentAverageError(void) const { return m_recentAverageError; }
    
private:
    vector<Layer> m_layers;
    double m_error;
    double m_recentAverageError;
    static double m_recentAverageSmoothingFactor;
};


//double Net::m_recentAverageSmoothingFactor = 100.0;

#endif /* defined(__neural__Net__) */
