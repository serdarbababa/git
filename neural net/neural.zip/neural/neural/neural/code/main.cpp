//
//  main.cpp
//  neural
//
//  Created by ser on 1/27/14.
//  Copyright (c) 2014 ser. All rights reserved.
//

#include <iostream>
#include "TrainingData.h"



void showVectorVals(string label, vector<double> &v)
{
    cout << label << " ";
    for (unsigned i = 0; i < v.size(); ++i) {
        cout << v[i] << " ";
    }
    
    cout << endl;
}

int main(int argc, const char * argv[])
{

    TrainingData trainData("../data/trainingData.txt");
    
    vector<unsigned> topology;
    trainData.getTopology(topology);
    
    Net myNet(topology);
    
    vector<double> inputVals, targetVals, resultVals;
    int trainingPass = 0;
    
    while (!trainData.isEof()) {
        ++trainingPass;
        cout << endl << "Pass " << trainingPass;
        
        
        if (trainData.getNextInputs(inputVals) != topology[0]) {
            break;
        }
        showVectorVals(": Inputs:", inputVals);
        myNet.feedForward(inputVals);
        
        
        myNet.getResults(resultVals);
        showVectorVals("Outputs:", resultVals);
        
        
        trainData.getTargetOutputs(targetVals);
        showVectorVals("Targets:", targetVals);
        assert(targetVals.size() == topology.back());
        
        myNet.backProp(targetVals);
        
        
        cout << "Net recent average error: "
        << myNet.getRecentAverageError() << endl;
    }
    
    cout << endl << "Done" << endl;
    
    
    return 0;
}

