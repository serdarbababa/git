//
//  TrainingData.h
//  neural
//
//  Created by ser on 1/27/14.
//  Copyright (c) 2014 ser. All rights reserved.
//

#ifndef __neural__TrainingData__
#define __neural__TrainingData__

#include <iostream>
#include <fstream>
#include <sstream>
#include "Net.h"
using namespace std;

class TrainingData
{
public:
    TrainingData(const string filename);
    bool isEof(void) { return m_trainingDataFile.eof(); }
    void getTopology(vector<unsigned> &topology);
    
    unsigned getNextInputs(vector<double> &inputVals);
    unsigned getTargetOutputs(vector<double> &targetOutputVals);
    
private:
    ifstream m_trainingDataFile;
};

#endif /* defined(__neural__TrainingData__) */
